#include "mainwindow.h"

#include "additemdialog.h"

#include <QAbstractItemView>
#include <QDialog>
#include <QFrame>
#include <QHeaderView>
#include <QHBoxLayout>
#include <QLabel>
#include <QListWidget>
#include <QPushButton>
#include <QSizePolicy>
#include <QStackedWidget>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QVBoxLayout>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      pageStack(new QStackedWidget(this)),
      pantryTable(nullptr),
      recentItemsList(nullptr)
{
    setWindowTitle("PantryPal Main");
    resize(1280, 760);
    setMinimumSize(960, 600);

    auto *mainView = new QWidget(this);
    setCentralWidget(mainView);

    auto *windowLayout = new QHBoxLayout(mainView);
    windowLayout->setContentsMargins(0, 0, 0, 0);
    windowLayout->setSpacing(0);

    auto *sidebar = new QFrame(mainView);
    sidebar->setObjectName("sidebar");
    sidebar->setFrameShape(QFrame::StyledPanel);
    sidebar->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);

    auto *sidebarLayout = new QVBoxLayout(sidebar);
    sidebarLayout->setContentsMargins(18, 24, 18, 24);
    sidebarLayout->setSpacing(10);

    auto *brandName = new QLabel("PantryPal", sidebar);
    brandName->setObjectName("brandName");
    sidebarLayout->addWidget(brandName);
    sidebarLayout->addSpacing(20);

    auto *dashboardButton = createNavigationButton("Dashboard");
    auto *pantryButton = createNavigationButton("Pantry");
    auto *shoppingListButton = createNavigationButton("Shopping List");
    auto *profileButton = createNavigationButton("Profile");

    sidebarLayout->addWidget(dashboardButton);
    sidebarLayout->addWidget(pantryButton);
    sidebarLayout->addWidget(shoppingListButton);
    sidebarLayout->addWidget(profileButton);
    sidebarLayout->addStretch();

    pageStack->addWidget(createDashboardPage());
    pageStack->addWidget(createPantryPage());
    pageStack->addWidget(createPlaceholderPage("Shopping List"));
    pageStack->addWidget(createPlaceholderPage("Profile"));

    connect(dashboardButton, &QPushButton::clicked, this, [this] { showPage(0); });
    connect(pantryButton, &QPushButton::clicked, this, [this] { showPage(1); });
    connect(shoppingListButton, &QPushButton::clicked, this, [this] { showPage(2); });
    connect(profileButton, &QPushButton::clicked, this, [this] { showPage(3); });

    windowLayout->addWidget(sidebar);
    windowLayout->addWidget(pageStack);
    windowLayout->setStretch(0, 1);
    windowLayout->setStretch(1, 4);

}

QPushButton *MainWindow::createNavigationButton(const QString &text)
{
    auto *button = new QPushButton(text);
    button->setProperty("navButton", true);
    button->setCursor(Qt::PointingHandCursor);
    button->setMinimumHeight(40);
    return button;
}

QPushButton *MainWindow::createStatButton(const QString &title)
{
    auto *button = new QPushButton(title);
    button->setProperty("statButton", true);
    button->setMinimumHeight(110);
    button->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    return button;
}

QWidget *MainWindow::createDashboardPage()
{
    auto *dashboard = new QWidget(pageStack);
    auto *dashboardLayout = new QVBoxLayout(dashboard);
    dashboardLayout->setContentsMargins(28, 28, 28, 28);
    dashboardLayout->setSpacing(20);

    auto *topRow = new QHBoxLayout;
    auto *pageTitle = new QLabel("Dashboard", dashboard);
    pageTitle->setObjectName("pageTitle");

    auto *addItemButton = new QPushButton("+  Add Item", dashboard);
    addItemButton->setObjectName("addItemButton");
    addItemButton->setMinimumSize(120, 40);
    addItemButton->setCursor(Qt::PointingHandCursor);
    connect(addItemButton, &QPushButton::clicked, this, &MainWindow::openAddItemDialog);

    topRow->addWidget(pageTitle);
    topRow->addStretch();
    topRow->addWidget(addItemButton);
    dashboardLayout->addLayout(topRow);

    auto *statsLayout = new QHBoxLayout;
    statsLayout->setSpacing(12);
    statsLayout->addWidget(createStatButton("Total Items"));
    statsLayout->addWidget(createStatButton("Expiring Soon"));
    statsLayout->addWidget(createStatButton("Expired"));
    statsLayout->addWidget(createStatButton("Running Low"));
    dashboardLayout->addLayout(statsLayout);

    auto *recentItemsPanel = new QFrame(dashboard);
    recentItemsPanel->setObjectName("recentItemsPanel");
    recentItemsPanel->setFrameShape(QFrame::StyledPanel);
    auto *recentLayout = new QVBoxLayout(recentItemsPanel);
    recentLayout->setContentsMargins(18, 16, 18, 16);
    auto *recentTitle = new QLabel("Recent Items", recentItemsPanel);
    recentLayout->addWidget(recentTitle);
    recentItemsList = new QListWidget(recentItemsPanel);
    recentItemsList->setSelectionMode(QAbstractItemView::NoSelection);
    recentItemsList->setFocusPolicy(Qt::NoFocus);
    recentLayout->addWidget(recentItemsList, 1);
    dashboardLayout->addWidget(recentItemsPanel, 1);

    return dashboard;
}

QWidget *MainWindow::createPantryPage()
{
    auto *pantryPage = new QWidget(pageStack);
    auto *pantryLayout = new QVBoxLayout(pantryPage);
    pantryLayout->setContentsMargins(28, 28, 28, 28);
    pantryLayout->setSpacing(18);

    auto *topRow = new QHBoxLayout;
    auto *pageTitle = new QLabel("Pantry", pantryPage);
    pageTitle->setObjectName("pageTitle");

    auto *addItemButton = new QPushButton("+  Add Item", pantryPage);
    addItemButton->setObjectName("addItemButton");
    addItemButton->setMinimumSize(120, 40);
    addItemButton->setCursor(Qt::PointingHandCursor);
    connect(addItemButton, &QPushButton::clicked, this, &MainWindow::openAddItemDialog);

    topRow->addWidget(pageTitle);
    topRow->addStretch();
    topRow->addWidget(addItemButton);
    pantryLayout->addLayout(topRow);

    pantryTable = new QTableWidget(0, 7, pantryPage);
    pantryTable->setHorizontalHeaderLabels({"Item name",
                                            "Quantity",
                                            "Unit",
                                            "Category",
                                            "Storage location",
                                            "Expiration date",
                                            "Minimum quantity"});
    pantryTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    pantryTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    pantryTable->setSelectionMode(QAbstractItemView::SingleSelection);
    pantryTable->verticalHeader()->setVisible(false);
    pantryTable->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    pantryTable->horizontalHeader()->setStretchLastSection(true);
    pantryTable->setSortingEnabled(true);
    pantryLayout->addWidget(pantryTable, 1);

    return pantryPage;
}

QWidget *MainWindow::createPlaceholderPage(const QString &title)
{
    auto *page = new QWidget(pageStack);
    auto *layout = new QVBoxLayout(page);
    layout->setContentsMargins(28, 28, 28, 28);

    auto *pageTitle = new QLabel(title, page);
    pageTitle->setObjectName("pageTitle");
    layout->addWidget(pageTitle, 0, Qt::AlignTop);
    layout->addStretch();
    return page;
}

void MainWindow::openAddItemDialog()
{
    AddItemDialog dialog(this);
    if (dialog.exec() == QDialog::Accepted) {
        addItemToPantry(dialog.pantryItem());
    }
}

void MainWindow::addItemToPantry(const PantryItem &item)
{
    pantryItems.append(item);
    recentItemsList->insertItem(0, item.name);

    pantryTable->setSortingEnabled(false);
    const int row = pantryTable->rowCount();
    pantryTable->insertRow(row);

    pantryTable->setItem(row, 0, new QTableWidgetItem(item.name));
    pantryTable->setItem(row, 1, new QTableWidgetItem(QString::number(item.quantity)));
    pantryTable->setItem(row, 2, new QTableWidgetItem(item.unit));
    pantryTable->setItem(row, 3, new QTableWidgetItem(item.category));
    pantryTable->setItem(row, 4, new QTableWidgetItem(item.storageLocation));
    pantryTable->setItem(row, 5, new QTableWidgetItem(item.expirationDate.toString("MM/dd/yyyy")));
    pantryTable->setItem(row, 6, new QTableWidgetItem(QString::number(item.minimumQuantity)));

    pantryTable->setSortingEnabled(true);
    pantryTable->resizeRowsToContents();
}

void MainWindow::showPage(int pageIndex)
{
    if (pageIndex >= 0 && pageIndex < pageStack->count()) {
        pageStack->setCurrentIndex(pageIndex);
    }
}
