#include "additemdialog.h"

#include <QAbstractSpinBox>
#include <QComboBox>
#include <QDate>
#include <QDateEdit>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QSpinBox>
#include <QStringList>
#include <QVBoxLayout>

AddItemDialog::AddItemDialog(QWidget *parent)
    : QDialog(parent),
      nameEdit(new QLineEdit(this)),
      categoryCombo(new QComboBox(this)),
      quantitySpin(new QSpinBox(this)),
      unitCombo(new QComboBox(this)),
      minimumQuantitySpin(new QSpinBox(this)),
      storageCombo(new QComboBox(this)),
      expirationDateEdit(new QDateEdit(this)),
      errorLabel(new QLabel(this))
{
    setWindowTitle("Add Pantry Item");
    setModal(true);
    setMinimumSize(510, 680);
    setSizeGripEnabled(false);

    auto *mainLayout = new QVBoxLayout(this);
    mainLayout->setContentsMargins(28, 24, 28, 28);
    mainLayout->setSpacing(14);

    auto *headingLayout = new QHBoxLayout;
    auto *heading = new QLabel("Add Pantry Item", this);
    heading->setObjectName("dialogHeading");

    auto *closeButton = new QPushButton(QString(QChar(0x00D7)), this);
    closeButton->setObjectName("closeButton");
    closeButton->setFixedSize(40, 40);
    closeButton->setToolTip("Close");
    connect(closeButton, &QPushButton::clicked, this, &QDialog::reject);

    headingLayout->addWidget(heading);
    headingLayout->addStretch();
    headingLayout->addWidget(closeButton);
    mainLayout->addLayout(headingLayout);

    errorLabel->setObjectName("errorLabel");
    errorLabel->setWordWrap(true);
    errorLabel->hide();
    mainLayout->addWidget(errorLabel);

    nameEdit->setPlaceholderText("Item name");
    nameEdit->setMaxLength(100);
    nameEdit->setClearButtonEnabled(true);
    nameEdit->setMinimumHeight(48);
    mainLayout->addWidget(nameEdit);

    categoryCombo->addItems({"Select category",
                             "Baking",
                             "Beverages",
                             "Canned Goods",
                             "Condiments",
                             "Dairy",
                             "Frozen",
                             "Grains",
                             "Meat",
                             "Produce",
                             "Seafood",
                             "Snacks",
                             "Other"});
    categoryCombo->setMinimumHeight(48);
    mainLayout->addWidget(categoryCombo);

    quantitySpin->setRange(0, 1000000);
    quantitySpin->setSpecialValueText("Quantity");
    quantitySpin->setValue(0);
    quantitySpin->setMinimumHeight(48);
    mainLayout->addWidget(quantitySpin);

    unitCombo->addItems({"Select unit",
                         "Each",
                         "Count",
                         "Bag",
                         "Bottle",
                         "Box",
                         "Can",
                         "Package",
                         "Gram",
                         "Kilogram",
                         "Ounce",
                         "Pound",
                         "Milliliter",
                         "Liter"});
    unitCombo->setMinimumHeight(48);
    mainLayout->addWidget(unitCombo);

    minimumQuantitySpin->setRange(-1, 1000000);
    minimumQuantitySpin->setSpecialValueText("Minimum quantity");
    minimumQuantitySpin->setValue(-1);
    minimumQuantitySpin->setMinimumHeight(48);
    mainLayout->addWidget(minimumQuantitySpin);

    storageCombo->addItems({"Select storage location",
                            "Pantry",
                            "Refrigerator",
                            "Freezer",
                            "Cabinet",
                            "Countertop",
                            "Other"});
    storageCombo->setMinimumHeight(48);
    mainLayout->addWidget(storageCombo);

    // A section-based date entry with no calendar. Qt limits months to 1-12
    // and limits the day to the valid range for the selected month and year.
    expirationDateEdit->setCalendarPopup(false);
    expirationDateEdit->setButtonSymbols(QAbstractSpinBox::NoButtons);
    expirationDateEdit->setDisplayFormat("MM/dd/yyyy");
    expirationDateEdit->setMinimumDate(QDate(1900, 1, 1));
    expirationDateEdit->setMaximumDate(QDate(2100, 12, 31));
    expirationDateEdit->setDate(QDate::currentDate());
    expirationDateEdit->setToolTip("Click the month, day, or year section, then type the value.");
    expirationDateEdit->setMinimumHeight(48);
    mainLayout->addWidget(expirationDateEdit);

    mainLayout->addSpacing(10);
    mainLayout->addStretch();

    auto *saveButton = new QPushButton("Add Item", this);
    saveButton->setObjectName("saveButton");
    saveButton->setMinimumHeight(50);
    saveButton->setDefault(true);
    connect(saveButton, &QPushButton::clicked, this, &AddItemDialog::saveItem);
    mainLayout->addWidget(saveButton);

    nameEdit->setFocus();
}

PantryItem AddItemDialog::pantryItem() const
{
    return savedItem;
}

void AddItemDialog::saveItem()
{
    if (!validateInput()) {
        return;
    }

    savedItem.name = nameEdit->text().trimmed();
    savedItem.quantity = quantitySpin->value();
    savedItem.unit = unitCombo->currentText();
    savedItem.category = categoryCombo->currentText();
    savedItem.storageLocation = storageCombo->currentText();
    savedItem.expirationDate = expirationDateEdit->date();
    savedItem.minimumQuantity = minimumQuantitySpin->value();

    accept();
}

bool AddItemDialog::validateInput()
{
    clearValidationState();

    QStringList missingFields;
    QWidget *firstInvalidWidget = nullptr;

    const auto checkField = [&](bool isValid, QWidget *widget, const QString &fieldName) {
        if (isValid) {
            return;
        }

        missingFields.append(fieldName);
        markInvalid(widget);
        if (!firstInvalidWidget) {
            firstInvalidWidget = widget;
        }
    };

    checkField(!nameEdit->text().trimmed().isEmpty(), nameEdit, "item name");
    checkField(categoryCombo->currentIndex() > 0, categoryCombo, "category");
    checkField(quantitySpin->value() > 0, quantitySpin, "quantity greater than 0");
    checkField(unitCombo->currentIndex() > 0, unitCombo, "unit");
    checkField(minimumQuantitySpin->value() >= 0,
               minimumQuantitySpin,
               "minimum quantity of 0 or more");
    checkField(storageCombo->currentIndex() > 0, storageCombo, "storage location");
    checkField(expirationDateEdit->date().isValid(),
               expirationDateEdit,
               "expiration date");

    if (missingFields.isEmpty()) {
        return true;
    }

    errorLabel->setText("Please enter or select: " + missingFields.join(", ") + ".");
    errorLabel->show();
    firstInvalidWidget->setFocus();
    adjustSize();
    return false;
}

void AddItemDialog::clearValidationState()
{
    errorLabel->hide();

    const QList<QWidget *> fields = {nameEdit,
                                     categoryCombo,
                                     quantitySpin,
                                     unitCombo,
                                     minimumQuantitySpin,
                                     storageCombo,
                                     expirationDateEdit};
    for (QWidget *field : fields) {
        field->setToolTip(QString());
    }
}

void AddItemDialog::markInvalid(QWidget *widget)
{
    widget->setToolTip("This field is required.");
}
