#ifndef ADDITEMDIALOG_H
#define ADDITEMDIALOG_H

#include "pantryitem.h"

#include <QDialog>

class QComboBox;
class QDateEdit;
class QLabel;
class QLineEdit;
class QSpinBox;

class AddItemDialog : public QDialog
{
public:
    explicit AddItemDialog(QWidget *parent = nullptr);

    PantryItem pantryItem() const;

private:
    void saveItem();
    bool validateInput();
    void clearValidationState();
    void markInvalid(QWidget *widget);

    QLineEdit *nameEdit;
    QComboBox *categoryCombo;
    QSpinBox *quantitySpin;
    QComboBox *unitCombo;
    QSpinBox *minimumQuantitySpin;
    QComboBox *storageCombo;
    QDateEdit *expirationDateEdit;
    QLabel *errorLabel;

    PantryItem savedItem;
};

#endif // ADDITEMDIALOG_H
