# PantryPal Main - Add Item

This C++ Qt Widgets project implements the Add Item task and connects it to a simple Pantry page.
The interface uses the original Qt system colors from the supplied project. No custom colors or color styles are added.

## Implemented acceptance criteria

- The **Add Item** button on both Dashboard and Pantry opens a modal dialog.
- The dialog collects item name, quantity, unit, category, storage location, expiration date, and minimum quantity.
- Every field is required.
- Quantity must be greater than zero.
- Minimum quantity must be zero or greater.
- Expiration date uses typed `MM/dd/yyyy` sections with no calendar popup; months are restricted to 01-12 and days are restricted to valid dates.
- Invalid input is rejected and an error message identifies what is missing.
- Saving from the Dashboard keeps the user on the Dashboard and adds only the item name to Recent Items.
- The full item is also added to the Pantry table without automatically opening the Pantry page.
- Closing the dialog does not create an item.

`pantryitem.h` is the shared data contract between the Add Item dialog and Pantry module. Add any future inventory fields to that structure so the modules remain consistent.

## Open and run in Qt Creator

1. Open Qt Creator.
2. Select **File > Open File or Project**.
3. Select `CMakeLists.txt` from this folder.
4. Choose a Qt 6 Desktop kit. Qt 5 Widgets is also supported.
5. Click **Configure Project**, then click **Run**.

## Verification steps

1. Run the application.
2. Click **Add Item**.
3. Click **Add Item** inside the empty dialog and verify the dialog stays open with validation errors.
4. Enter valid information in every field.
5. Click **Add Item**.
6. Verify the Dashboard remains open and Recent Items shows only the new item's name.
7. Open the Pantry page and verify it contains one row with all the entered values.
8. Open the dialog again, enter a quantity of zero or leave another field unselected, and verify the item is rejected.

Verification by: ____________________

Verification: _______________________
