#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "pantryitem.h"

#include <QMainWindow>
#include <QString>
#include <QVector>

class QPushButton;
class QListWidget;
class QStackedWidget;
class QTableWidget;
class QWidget;

class MainWindow : public QMainWindow
{
public:
    explicit MainWindow(QWidget *parent = nullptr);

private:
    QPushButton *createNavigationButton(const QString &text);
    QPushButton *createStatButton(const QString &title);
    QWidget *createDashboardPage();
    QWidget *createPantryPage();
    QWidget *createPlaceholderPage(const QString &title);

    void openAddItemDialog();
    void addItemToPantry(const PantryItem &item);
    void showPage(int pageIndex);

    QStackedWidget *pageStack;
    QTableWidget *pantryTable;
    QListWidget *recentItemsList;
    QVector<PantryItem> pantryItems;
};

#endif // MAINWINDOW_H
