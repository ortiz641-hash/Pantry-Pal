#ifndef PANTRYITEM_H
#define PANTRYITEM_H

#include <QDate>
#include <QString>

// This is the single item format shared by Add Item and Pantry.
// Add future inventory fields here so both modules remain consistent.
struct PantryItem
{
    QString name;
    int quantity = 0;
    QString unit;
    QString category;
    QString storageLocation;
    QDate expirationDate;
    int minimumQuantity = 0;
};

#endif // PANTRYITEM_H
